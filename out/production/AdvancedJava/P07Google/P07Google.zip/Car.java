package P07Google;

public class Car {
    private String model;
    private int Speed;

    public Car(String model,int speed){
        this.model = model;
        this.Speed = speed;

    }
    @Override
    public String toString(){
        return model + " " + Speed;
    }
}
