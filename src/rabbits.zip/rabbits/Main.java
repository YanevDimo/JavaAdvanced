package rabbits;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
          Scanner scanner = new Scanner(System.in);

          Rabbit rabbit = new Rabbit("Bunny", "Homan");


    }
}
